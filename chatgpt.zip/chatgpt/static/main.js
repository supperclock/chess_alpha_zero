const PIECE_TO_GLYPH = {
  'r': '車', 'h': '馬', 'c': '炮', 'e': '象', 'a': '士', 'g': '將', 's': '卒',
  'R': '車', 'H': '馬', 'C': '炮', 'E': '相', 'A': '仕', 'G': '帥', 'S': '兵',
  '.': ''
};

const state = {
  board: [],
  side_to_move: 'red',
  human_side: 'red',
  legal_moves: [],
  selected: null,
  ai_thinking: false,
};

const boardCanvas = document.getElementById('board');
const ctx = boardCanvas.getContext('2d');
const statusText = document.getElementById('statusText');

function drawBoard() {
  const width = boardCanvas.width;
  const height = boardCanvas.height;
  ctx.clearRect(0, 0, width, height);

  const marginX = 30;
  const marginY = 30;
  const cellW = (width - marginX * 2) / 9;
  const cellH = (height - marginY * 2) / 10;

  ctx.strokeStyle = '#333333';
  for (let r = 0; r < 10; r++) {
    const y = marginY + r * cellH;
    ctx.beginPath();
    ctx.moveTo(marginX, y);
    ctx.lineTo(width - marginX, y);
    ctx.stroke();
  }
  for (let c = 0; c < 9; c++) {
    const x = marginX + c * cellW;
    ctx.beginPath();
    ctx.moveTo(x, marginY);
    ctx.lineTo(x, height - marginY);
    ctx.stroke();
  }

  // River text
  ctx.fillStyle = '#333333';
  ctx.font = '18px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('楚河    汉界', width / 2, marginY + 4.5 * cellH);

  // pieces
  for (let r = 0; r < 10; r++) {
    for (let c = 0; c < 9; c++) {
      const p = state.board[r]?.[c] ?? '.';
      const x0 = marginX + c * cellW;
      const y0 = marginY + r * cellH;
      const x1 = x0 + cellW;
      const y1 = y0 + cellH;
      if (p !== '.') {
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = '#333333';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse((x0 + x1) / 2, (y0 + y1) / 2, (cellW - 8) / 2, (cellH - 8) / 2, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = /[A-Z]/.test(p) ? '#c00000' : '#000000';
        ctx.font = 'bold 18px Arial';
        ctx.fillText(PIECE_TO_GLYPH[p] || p, (x0 + x1) / 2, (y0 + y1) / 2);
      }
    }
  }

  // selected
  if (state.selected) {
    const [sr, sc] = state.selected;
    const x0 = marginX + sc * cellW;
    const y0 = marginY + sr * cellH;
    const x1 = x0 + cellW;
    const y1 = y0 + cellH;
    ctx.strokeStyle = '#00aaff';
    ctx.lineWidth = 3;
    ctx.strokeRect(x0 + 2, y0 + 2, (x1 - x0) - 4, (y1 - y0) - 4);
  }
}

function coordFromEvent(evt) {
  const rect = boardCanvas.getBoundingClientRect();
  const marginX = 30;
  const marginY = 30;
  const width = boardCanvas.width;
  const height = boardCanvas.height;
  const cellW = (width - marginX * 2) / 9;
  const cellH = (height - marginY * 2) / 10;
  const x = evt.clientX - rect.left;
  const y = evt.clientY - rect.top;
  const c = Math.floor((x - marginX) / cellW);
  const r = Math.floor((y - marginY) / cellH);
  if (r < 0 || r >= 10 || c < 0 || c >= 9) return null;
  return [r, c];
}

async function fetchState() {
  const res = await fetch('/api/state');
  const data = await res.json();
  Object.assign(state, data);
  statusText.textContent = state.ai_thinking ? 'AI 思考中...' : '就绪';
  drawBoard();
}

async function newGame() {
  const humanSide = document.getElementById('humanSide').value;
  const res = await fetch('/api/new_game', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ human_side: humanSide })
  });
  const data = await res.json();
  Object.assign(state, data);
  statusText.textContent = '新开局';
  drawBoard();
  // If AI moves first
  if (state.side_to_move !== state.human_side) {
    await aiMove();
  }
}

async function humanMove(fromRC, toRC) {
  const res = await fetch('/api/move', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: fromRC, to: toRC })
  });
  const data = await res.json();
  if (!data.ok) {
    statusText.textContent = '非法走步';
    state.selected = null;
    drawBoard();
    return false;
  }
  Object.assign(state, data);
  state.selected = null;
  drawBoard();
  if (state.terminal) {
    alert(resultLabel(state.result));
    return true;
  }
  return true;
}

function resultLabel(z) {
  if (z === 0) return '平局';
  return z > 0 ? '红胜' : '黑胜';
}

async function aiMove() {
  statusText.textContent = 'AI 思考中...';
  const res = await fetch('/api/ai_move', { method: 'POST' });
  const data = await res.json();
  if (!data.ok) {
    statusText.textContent = 'AI 错误: ' + data.error;
    return;
  }
  Object.assign(state, data);
  drawBoard();
  if (state.terminal) {
    alert(resultLabel(state.result));
  } else {
    statusText.textContent = '请你走子';
  }
}

async function applySettings() {
  const sims = parseInt(document.getElementById('sims').value, 10);
  const device = document.getElementById('device').value;
  const model_path = document.getElementById('modelPath').value || null;
  const res = await fetch('/api/settings', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sims, device, model_path })
  });
  const data = await res.json();
  if (!data.ok) {
    alert('设置失败: ' + data.error);
    return;
  }
  Object.assign(state, data);
  drawBoard();
}

boardCanvas.addEventListener('click', async (evt) => {
  if (state.ai_thinking) return;
  if (state.side_to_move !== state.human_side) return;
  const rc = coordFromEvent(evt);
  if (!rc) return;
  const [r, c] = rc;
  const p = state.board[r]?.[c] ?? '.';
  if (!state.selected) {
    if (p === '.') return;
    const isRed = /[A-Z]/.test(p);
    if ((state.human_side === 'red' && !isRed) || (state.human_side === 'black' && isRed)) return;
    state.selected = [r, c];
    drawBoard();
  } else {
    const [r0, c0] = state.selected;
    const ok = await humanMove([r0, c0], [r, c]);
    if (ok && !state.terminal && state.side_to_move !== state.human_side) {
      await aiMove();
    }
  }
});

document.getElementById('newGameBtn').addEventListener('click', newGame);
document.getElementById('applySettings').addEventListener('click', applySettings);

window.addEventListener('load', async () => {
  const sres = await fetch('/api/settings');
  const s = await sres.json();
  document.getElementById('sims').value = s.sims;
  document.getElementById('device').value = s.device;
  document.getElementById('modelPath').value = s.model_path || '';
  await fetchState();
});


